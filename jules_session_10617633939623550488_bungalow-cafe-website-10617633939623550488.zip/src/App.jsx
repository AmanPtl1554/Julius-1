import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import { Menu, Specials } from './components/Menu';
import { RatingsAndReviews, Gallery } from './components/RatingsAndGallery';
import { ContactAndReservation, Footer } from './components/ContactAndFooter';

export default function App() {
  const [reservationOpen, setReservationOpen] = useState(false);

  return (
    <div className="min-h-screen bg-bungalow-50 text-stone-800">
      <Navbar onOpenReservation={() => setReservationOpen(true)} />
      <main>
        <Hero onOpenReservation={() => setReservationOpen(true)} />
        <About />
        <Specials />
        <Menu />
        <RatingsAndReviews />
        <Gallery />
        <ContactAndReservation />
      </main>
      <Footer />

      {/* Reservation Modal */}
      {reservationOpen && (
        <ContactAndReservation
          isModal={true}
          onCloseModal={() => setReservationOpen(false)}
        />
      )}
    </div>
  );
}
