import React, { useState } from 'react';
import { Star, Award, ThumbsUp, MessageSquare, ShieldCheck, Quote, Camera, Layers, CheckCircle2 } from 'lucide-react';

export function RatingsAndReviews() {
  const [filterRating, setFilterRating] = useState('all');

  const platforms = [
    {
      name: 'Zomato',
      score: '4.6/5',
      votes: '683 votes',
      badgeColor: 'bg-red-500/10 text-red-700 border-red-200',
      iconColor: 'text-red-500',
    },
    {
      name: 'Justdial',
      score: '4.3/5',
      votes: '2,681 reviews',
      badgeColor: 'bg-amber-500/10 text-amber-800 border-amber-200',
      iconColor: 'text-amber-500',
    },
    {
      name: 'Magicpin',
      score: '4.4/5',
      votes: '62 reviews',
      badgeColor: 'bg-pink-500/10 text-pink-700 border-pink-200',
      iconColor: 'text-pink-500',
    },
  ];

  const customerReviews = [
    {
      id: 1,
      author: 'Manthan Negandhi',
      date: 'Sep 10, 2023',
      rating: 5,
      type: 'DINING',
      highlight: 'Best Sizzlers in Surat',
      comment:
        'One of the best sizzlers had in Surat 1000% leaving behind the famous surat sizzler places like level 5 or even sizzling salsa ONE MUST TRY SIZZLERS HERE',
      avatarColor: 'bg-amber-600',
    },
    {
      id: 2,
      author: 'Manish Jain',
      date: 'Jul 30, 2023',
      rating: 5,
      type: 'DINING',
      highlight: 'Scrumptious Pizza & Ambience',
      comment:
        'The Bungalow Cafe serves scrumptious pizzas for you to enjoy. The staff is extremely kind, courteous and helpful! Truly a great cafe experience for big-time foodies in Surat.',
      avatarColor: 'bg-emerald-600',
    },
    {
      id: 3,
      author: 'Harshil Patel',
      date: 'Jun 21, 2023',
      rating: 5,
      type: 'DINING',
      highlight: 'Cozy Atmosphere in Vesu',
      comment:
        'Awesome vibe at Rivoli Heights! Great place to hang out with friends in Vesu. Highly recommended for sizzlers, artisan pizzas and cold coffees.',
      avatarColor: 'bg-blue-600',
    },
    {
      id: 4,
      author: 'Manthan Negandhi',
      date: 'Sep 09, 2023',
      rating: 5,
      type: 'DINING',
      highlight: 'Great Food & Quick Service',
      comment:
        'Consistently delicious food and top notch quality. Sizzling platters and beverages are served piping hot and fresh.',
      avatarColor: 'bg-amber-600',
    },
  ];

  return (
    <section id="ratings" className="py-20 bg-bungalow-100/60 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-amber-800 font-bold uppercase text-xs tracking-widest bg-amber-200/60 px-3.5 py-1.5 rounded-full border border-amber-300">
            Trusted by Thousands of Surat Foodies
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-stone-900 mt-3 mb-4">
            Ratings & Customer Dining Reviews
          </h2>
          <p className="text-stone-600 text-sm sm:text-base">
            See what our guests and local food lovers have to say about our scrumptious pizzas, sizzlers, and hospitality.
          </p>
        </div>

        {/* Platform Scores Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {platforms.map((p) => (
            <div
              key={p.name}
              className="bg-white rounded-3xl p-6 shadow-md border border-stone-200/80 flex items-center justify-between hover:shadow-lg transition-shadow"
            >
              <div>
                <p className="text-xs uppercase font-bold tracking-wider text-stone-500 mb-1">{p.name}</p>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-serif font-extrabold text-stone-900">{p.score}</span>
                  <div className="flex text-amber-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                </div>
                <p className="text-xs text-stone-500 mt-1">{p.votes}</p>
              </div>
              <div className={`p-3.5 rounded-2xl border ${p.badgeColor}`}>
                <Award className={`w-7 h-7 ${p.iconColor}`} />
              </div>
            </div>
          ))}
        </div>

        {/* Customer Reviews Section */}
        <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl border border-stone-200/80">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-stone-200">
            <div>
              <h3 className="text-2xl font-serif font-bold text-stone-900">Dining Reviews from Visitors</h3>
              <p className="text-xs sm:text-sm text-stone-500">Real feedback from verified guests in Vesu, Surat</p>
            </div>

            <div className="flex items-center gap-2 bg-stone-100 p-1 rounded-xl">
              <button
                onClick={() => setFilterRating('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  filterRating === 'all'
                    ? 'bg-amber-500 text-stone-950 shadow'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                All Reviews
              </button>
              <button
                onClick={() => setFilterRating('5')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  filterRating === '5'
                    ? 'bg-amber-500 text-stone-950 shadow'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                5★ Rating Only
              </button>
            </div>
          </div>

          {/* Reviews Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {customerReviews
              .filter((rev) => filterRating === 'all' || rev.rating === parseInt(filterRating))
              .map((rev) => (
                <div
                  key={rev.id}
                  className="bg-bungalow-50/70 rounded-2xl p-6 border border-stone-200/70 flex flex-col justify-between hover:border-amber-300 transition-colors"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-full ${rev.avatarColor} text-white font-bold flex items-center justify-center text-sm shadow`}
                        >
                          {rev.author.charAt(0)}
                        </div>
                        <div>
                          <h4 className="font-bold text-stone-900 text-sm">{rev.author}</h4>
                          <span className="text-[10px] text-stone-500 uppercase tracking-wider">{rev.date}</span>
                        </div>
                      </div>

                      <div className="flex flex-col items-end">
                        <div className="flex text-amber-400">
                          {[...Array(rev.rating)].map((_, i) => (
                            <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          ))}
                        </div>
                        <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-2 py-0.5 rounded mt-1">
                          {rev.type}
                        </span>
                      </div>
                    </div>

                    <h5 className="font-serif font-bold text-amber-900 text-base mb-2">{rev.highlight}</h5>

                    <p className="text-stone-700 text-xs sm:text-sm leading-relaxed italic">
                      "{rev.comment}"
                    </p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-stone-200/60 flex items-center justify-between text-xs text-stone-500">
                    <span className="flex items-center gap-1">
                      <ThumbsUp className="w-3.5 h-3.5 text-amber-600" /> Helpful
                    </span>
                    <span className="text-stone-400">Verified Diner • Vesu</span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function Gallery() {
  const [activeTab, setActiveTab] = useState('all');

  const galleryImages = [
    {
      id: 1,
      category: 'ambience',
      title: 'Cozy Bungalow Interior',
      caption: 'Warm wooden aesthetic & relaxing seating',
      url: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&q=80&w=800',
    },
    {
      id: 2,
      category: 'pizzas',
      title: 'Scrumptious Gourmet Pizza',
      caption: 'Freshly baked pizza loaded with toppings',
      url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800',
    },
    {
      id: 3,
      category: 'sizzlers',
      title: 'Sizzling Platter Special',
      caption: 'Surat’s 1000% recommended sizzler',
      url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=800',
    },
    {
      id: 4,
      category: 'drinks',
      title: 'Handcrafted Espresso Drinks',
      caption: 'Freshly brewed coffees & chilled frappes',
      url: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&q=80&w=800',
    },
    {
      id: 5,
      category: 'ambience',
      title: 'Outdoor Bungalow Terrace',
      caption: 'Ideal setting for evening gatherings in Vesu',
      url: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=800',
    },
    {
      id: 6,
      category: 'pizzas',
      title: 'Cheesy Paneer Tikka Pizza',
      caption: 'Indian spice meets rich Italian pizza',
      url: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=800',
    },
  ];

  const filteredGallery =
    activeTab === 'all'
      ? galleryImages
      : galleryImages.filter((img) => img.category === activeTab);

  return (
    <section id="gallery" className="py-20 bg-stone-950 text-stone-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-amber-400 font-bold uppercase text-xs tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
            Visual Experience
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-stone-100 mt-3 mb-4">
            Photos & Cafe Gallery
          </h2>
          <p className="text-stone-400 text-sm sm:text-base">
            Take a visual tour inside The Bungalow Cafe, our delicious food presentations, and cozy ambience.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-10">
          {[
            { id: 'all', label: 'All Photos' },
            { id: 'ambience', label: 'Ambience' },
            { id: 'pizzas', label: 'Pizzas' },
            { id: 'sizzlers', label: 'Sizzlers' },
            { id: 'drinks', label: 'Coffees & Drinks' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? 'bg-amber-500 text-stone-950 shadow-md'
                  : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGallery.map((img) => (
            <div
              key={img.id}
              className="group relative h-72 rounded-3xl overflow-hidden bg-stone-900 border border-stone-800 shadow-xl"
            >
              <img
                src={img.url}
                alt={img.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-85 group-hover:opacity-100"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity"></div>
              
              <div className="absolute bottom-0 left-0 right-0 p-6 transform translate-y-2 group-hover:translate-y-0 transition-transform">
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider bg-amber-500/20 px-2.5 py-1 rounded-md border border-amber-500/30 inline-block mb-1.5">
                  {img.category}
                </span>
                <h3 className="font-serif font-bold text-lg text-stone-100">{img.title}</h3>
                <p className="text-xs text-stone-300 mt-1 font-light">{img.caption}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
