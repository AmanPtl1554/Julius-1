import React, { useState } from 'react';
import { MapPin, Phone, Clock, Calendar, Users, Send, Navigation, CheckCircle, AlertCircle, Coffee, Heart } from 'lucide-react';

export function ContactAndReservation({ isModal, onCloseModal }) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    guests: '2',
    date: '',
    time: '19:00',
    specialRequest: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const formContent = (
    <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-stone-200">
      <div className="flex items-center justify-between mb-6">
        <div>
          <span className="text-amber-700 font-bold uppercase text-[11px] tracking-wider bg-amber-100 px-3 py-1 rounded-full">
            Table Booking
          </span>
          <h3 className="text-2xl font-serif font-bold text-stone-900 mt-2">
            Reserve Your Table
          </h3>
          <p className="text-xs sm:text-sm text-stone-500">
            Book a spot at The Bungalow Cafe in Vesu, Surat
          </p>
        </div>

        {isModal && (
          <button
            onClick={onCloseModal}
            className="p-2 text-stone-400 hover:text-stone-700 text-lg font-bold"
          >
            ✕
          </button>
        )}
      </div>

      {submitted ? (
        <div className="text-center py-10 space-y-4">
          <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle className="w-10 h-10" />
          </div>
          <h4 className="text-2xl font-serif font-bold text-stone-900">Reservation Requested!</h4>
          <p className="text-stone-600 text-sm max-w-sm mx-auto">
            Thank you, <strong className="text-stone-800">{formData.name}</strong>. Our cafe staff will confirm your booking for {formData.guests} guests shortly on <span className="font-semibold">{formData.phone}</span>.
          </p>
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
            📍 B 401 Rivoli Heights, Vesu Main Road, Surat • Opens at 12:00 PM
          </div>
          <button
            onClick={() => {
              setSubmitted(false);
              if (isModal) onCloseModal();
            }}
            className="mt-4 px-6 py-2.5 bg-stone-900 text-amber-300 font-semibold rounded-full text-xs shadow"
          >
            {isModal ? 'Close Window' : 'Book Another Table'}
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">Full Name</label>
            <input
              type="text"
              required
              placeholder="Your Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">Phone Number</label>
              <input
                type="tel"
                required
                placeholder="097274 21004"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">Number of Guests</label>
              <select
                value={formData.guests}
                onChange={(e) => setFormData({ ...formData, guests: e.target.value })}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500"
              >
                <option value="1">1 Person</option>
                <option value="2">2 Persons (₹1,000 avg)</option>
                <option value="3-4">3 - 4 Persons</option>
                <option value="5-8">5 - 8 Persons (Group)</option>
                <option value="8+">8+ Large Party</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">Date</label>
              <input
                type="date"
                required
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 text-stone-800"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">Preferred Time</label>
              <select
                value={formData.time}
                onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500"
              >
                <option value="12:00">12:00 PM (Lunch)</option>
                <option value="13:30">01:30 PM</option>
                <option value="15:00">03:00 PM</option>
                <option value="17:00">05:00 PM (Tea/Coffee)</option>
                <option value="19:00">07:00 PM (Dinner)</option>
                <option value="20:30">08:30 PM</option>
                <option value="22:00">10:00 PM</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">Special Requests / Occasion</label>
            <textarea
              rows={2}
              placeholder="e.g. Birthday celebration, pizza preference, window seat..."
              value={formData.specialRequest}
              onChange={(e) => setFormData({ ...formData, specialRequest: e.target.value })}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-amber-500 resize-none"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-stone-950 font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>Confirm Table Reservation Request</span>
          </button>
        </form>
      )}
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md overflow-y-auto">
        <div className="max-w-lg w-full my-8">{formContent}</div>
      </div>
    );
  }

  return (
    <section id="contact" className="py-20 bg-bungalow-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-amber-800 font-bold uppercase text-xs tracking-widest bg-amber-200/60 px-3.5 py-1.5 rounded-full border border-amber-300">
            Visit Us in Surat
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-stone-900 mt-3 mb-4">
            Contact & Location Details
          </h2>
          <p className="text-stone-600 text-sm sm:text-base">
            Drop by for scrumptious pizzas, sizzlers and coffee, or reach out to us directly.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          
          {/* Location & Info Card */}
          <div className="space-y-6">
            <div className="bg-bungalow-950 text-stone-100 rounded-3xl p-6 sm:p-8 shadow-xl border border-bungalow-800 space-y-6">
              
              <div className="flex items-start gap-4">
                <div className="p-3 bg-amber-500/20 text-amber-400 rounded-2xl shrink-0">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-lg text-stone-100">Cafe Address</h4>
                  <p className="text-stone-300 text-sm leading-relaxed mt-1">
                    B 401 Rivoli Heights, Vesu Main Road, Surat, Gujarat
                  </p>
                  <p className="text-stone-400 text-xs mt-1">
                    (Also formerly associated with Aagam Viviana location near Phoenix Tower, Vesu)
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 pt-4 border-t border-stone-800">
                <div className="p-3 bg-amber-500/20 text-amber-400 rounded-2xl shrink-0">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-lg text-stone-100">Phone & Inquiries</h4>
                  <p className="text-stone-300 text-sm font-semibold mt-1">
                    <a href="tel:09727421004" className="hover:text-amber-400 transition-colors">
                      097274 21004
                    </a>
                  </p>
                  <p className="text-stone-300 text-sm font-semibold mt-0.5">
                    <a href="tel:+919429931984" className="hover:text-amber-400 transition-colors">
                      +91 94299 31984
                    </a>
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4 pt-4 border-t border-stone-800">
                <div className="p-3 bg-amber-500/20 text-amber-400 rounded-2xl shrink-0">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-lg text-stone-100">Opening Hours</h4>
                  <p className="text-stone-300 text-sm mt-1">
                    Daily: <strong className="text-amber-300">Opens at 12:00 PM</strong>
                  </p>
                  <p className="text-stone-400 text-xs mt-0.5">
                    Average Cost: ₹1,000 for two people approx.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-stone-800 flex flex-col sm:flex-row gap-3">
                <a
                  href="https://maps.google.com/?q=The+Bungalow+Cafe+Vesu+Surat"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 px-4 bg-amber-500 hover:bg-amber-600 text-stone-950 font-bold text-xs sm:text-sm rounded-xl transition-all flex items-center justify-center gap-2"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Get Driving Directions</span>
                </a>

                <a
                  href="tel:09727421004"
                  className="flex-1 py-3 px-4 bg-stone-800 hover:bg-stone-700 text-stone-100 font-bold text-xs sm:text-sm rounded-xl transition-all flex items-center justify-center gap-2 border border-stone-700"
                >
                  <Phone className="w-4 h-4 text-amber-400" />
                  <span>Call Cafe Directly</span>
                </a>
              </div>

            </div>

            {/* Quick Map Widget Simulation */}
            <div className="bg-stone-200 rounded-3xl h-52 overflow-hidden relative shadow-md border border-stone-300">
              <iframe
                title="The Bungalow Cafe Map Location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3721.282582845308!2d72.775833!3d21.141111!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjHCsDA4JzI4LjAiTiA3MsKwNDYnMzMuMCJF!5e0!3m2!1sen!2sin!4v1620000000000!5m2!1sen!2sin"
                className="w-full h-full border-0 grayscale opacity-80 hover:grayscale-0 hover:opacity-100 transition-all duration-300"
                loading="lazy"
              ></iframe>
              <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-full text-[11px] font-bold text-stone-900 shadow">
                📍 Vesu Main Road, Surat
              </div>
            </div>
          </div>

          {/* Form */}
          <div>{formContent}</div>

        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-bungalow-950 text-stone-400 pt-16 pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400">
                <Coffee className="w-5 h-5" />
              </div>
              <span className="font-serif text-2xl font-bold text-stone-100">
                The Bungalow Cafe
              </span>
            </div>
            <p className="text-xs leading-relaxed text-stone-400">
              Surat's favorite destination for scrumptious pizzas, 1000% top sizzlers, handcrafted coffee, and authentic Continental dining in Vesu.
            </p>
            <div className="pt-2 text-xs text-amber-300 font-semibold">
              4.6 / 5 Rating on Zomato • 683+ Votes
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-serif font-bold text-stone-100 text-sm tracking-wider uppercase mb-4">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li><a href="#home" className="hover:text-amber-400 transition-colors">Home Page</a></li>
              <li><a href="#about" className="hover:text-amber-400 transition-colors">About Our Cafe</a></li>
              <li><a href="#menu" className="hover:text-amber-400 transition-colors">Full Food & Beverage Menu</a></li>
              <li><a href="#specials" className="hover:text-amber-400 transition-colors">Signature Sizzlers & Pizzas</a></li>
              <li><a href="#ratings" className="hover:text-amber-400 transition-colors">Customer Reviews & Ratings</a></li>
              <li><a href="#gallery" className="hover:text-amber-400 transition-colors">Photo Gallery</a></li>
              <li><a href="#contact" className="hover:text-amber-400 transition-colors">Contact & Directions</a></li>
            </ul>
          </div>

          {/* Cuisine Specials */}
          <div>
            <h4 className="font-serif font-bold text-stone-100 text-sm tracking-wider uppercase mb-4">
              Cuisines & Dishes
            </h4>
            <ul className="space-y-2 text-xs">
              <li>Scrumptious Artisan Pizzas</li>
              <li>Surat's Top Sizzler Platters</li>
              <li>Continental & Pasta Dishes</li>
              <li>Fast Food & Burger Combos</li>
              <li>Lebanese Falafel Wraps</li>
              <li>British Toasties & Hot Teas</li>
              <li>Espresso & Cold Frappes</li>
            </ul>
          </div>

          {/* Address & Hours */}
          <div>
            <h4 className="font-serif font-bold text-stone-100 text-sm tracking-wider uppercase mb-4">
              Location & Hours
            </h4>
            <address className="not-italic text-xs space-y-2 text-stone-400">
              <p className="text-stone-200 font-semibold">The Bungalow Cafe</p>
              <p>B 401 Rivoli Heights, Vesu Main Road, Surat, GJ</p>
              <p className="pt-1">Phone: <a href="tel:09727421004" className="text-amber-300 font-semibold">097274 21004</a></p>
              <p>Opens Daily at 12:00 PM</p>
            </address>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-stone-800/80 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-4">
          <p>© {new Date().getFullYear()} The Bungalow Cafe, Vesu, Surat. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Crafted with <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" /> for Surat Foodies
          </p>
        </div>
      </div>
    </footer>
  );
}
