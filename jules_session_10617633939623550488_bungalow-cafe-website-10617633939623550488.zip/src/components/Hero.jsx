import React from 'react';
import { Star, MapPin, Clock, Flame, UtensilsCrossed, Phone, ArrowRight, ShieldCheck } from 'lucide-react';

export default function Hero({ onOpenReservation }) {
  return (
    <section id="home" className="relative min-h-screen pt-28 pb-16 flex items-center justify-center bg-bungalow-950 overflow-hidden">
      {/* Background visual image with dark atmospheric overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&q=80&w=1920"
          alt="The Bungalow Cafe Ambience"
          className="w-full h-full object-cover opacity-25 scale-105 transform animate-pulse duration-[10000ms]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bungalow-950 via-bungalow-950/70 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-bungalow-950/90 via-transparent to-bungalow-950/90"></div>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
        {/* Rating Badge */}
        <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/30 backdrop-blur-md px-4 py-1.5 rounded-full mb-6 text-amber-300 text-xs sm:text-sm font-medium">
          <div className="flex items-center text-amber-400">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span className="ml-1 font-bold">4.6/5</span>
          </div>
          <span className="text-stone-400">•</span>
          <span>Top-Rated Cafe on Zomato (683+ votes)</span>
        </div>

        {/* Headline */}
        <h1 className="text-4xl sm:text-6xl md:text-7xl font-serif font-extrabold text-stone-100 tracking-tight leading-tight max-w-4xl mx-auto mb-6">
          Scrumptious Pizzas & <br className="hidden sm:inline" />
          <span className="bg-gradient-to-r from-amber-200 via-amber-400 to-amber-500 bg-clip-text text-transparent">
            Surat's Finest Sizzlers
          </span>
        </h1>

        {/* Subtitle */}
        <p className="text-base sm:text-lg md:text-xl text-stone-300 max-w-2xl mx-auto mb-8 font-light leading-relaxed">
          Welcome to <strong className="text-amber-200 font-semibold">The Bungalow Cafe</strong> in Vesu, Surat. A cozy sanctuary for foodies serving gourmet pizzas, sizzlers, Continental, Fast Food, Lebanese & British delicacies.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <a
            href="#menu"
            className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-stone-950 font-bold text-base shadow-lg shadow-amber-500/20 hover:shadow-amber-500/30 transition-all flex items-center justify-center gap-2 group"
          >
            <UtensilsCrossed className="w-5 h-5" />
            <span>Explore Menu</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>

          <button
            onClick={onOpenReservation}
            className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-stone-900/80 hover:bg-stone-800 text-amber-300 border border-amber-500/40 hover:border-amber-400 font-semibold text-base transition-all flex items-center justify-center gap-2"
          >
            <span>Reserve Table</span>
          </button>

          <a
            href="#contact"
            className="w-full sm:w-auto px-6 py-3.5 rounded-full bg-stone-900/40 hover:bg-stone-800/60 text-stone-300 border border-stone-700 text-base transition-all flex items-center justify-center gap-2"
          >
            <MapPin className="w-4 h-4 text-amber-400" />
            <span>Get Directions</span>
          </a>
        </div>

        {/* Highlights Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-6 border-t border-stone-800/80 text-left">
          <div className="p-3 rounded-xl bg-stone-900/40 border border-stone-800/60 flex items-start gap-3">
            <Flame className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs text-stone-400">Must Try Sizzlers</p>
              <p className="text-sm font-semibold text-stone-200">1000% Surat Favorite</p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-stone-900/40 border border-stone-800/60 flex items-start gap-3">
            <Star className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs text-stone-400">High Ratings</p>
              <p className="text-sm font-semibold text-stone-200">4.6 Zomato • 4.3 Justdial</p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-stone-900/40 border border-stone-800/60 flex items-start gap-3">
            <MapPin className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs text-stone-400">Location</p>
              <p className="text-sm font-semibold text-stone-200">Vesu Main Road, Surat</p>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-stone-900/40 border border-stone-800/60 flex items-start gap-3">
            <Clock className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <p className="text-xs text-stone-400">Opening Hours</p>
              <p className="text-sm font-semibold text-stone-200">Opens at 12:00 PM</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
