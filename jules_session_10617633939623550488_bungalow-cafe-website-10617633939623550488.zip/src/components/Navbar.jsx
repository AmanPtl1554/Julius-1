import React, { useState, useEffect } from 'react';
import { Coffee, Phone, MapPin, Clock, Menu as MenuIcon, X, Calendar, ChevronRight } from 'lucide-react';

export default function Navbar({ onOpenReservation }) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Menu', href: '#menu' },
    { name: 'Specials', href: '#specials' },
    { name: 'Ratings', href: '#ratings' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-bungalow-950/95 backdrop-blur-md py-3 shadow-lg border-b border-bungalow-800/50'
          : 'bg-gradient-to-b from-bungalow-950/90 via-bungalow-950/60 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo & Branding */}
          <a href="#home" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-full bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 group-hover:scale-105 transition-transform">
              <Coffee className="w-5 h-5 text-amber-400" />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-amber-100 group-hover:text-amber-400 transition-colors">
                The Bungalow Cafe
              </span>
              <span className="text-[10px] tracking-widest uppercase text-amber-300/80 font-medium">
                Vesu, Surat • Coffee House
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="px-3 py-2 rounded-md text-sm font-medium text-stone-200 hover:text-amber-300 hover:bg-amber-500/10 transition-colors"
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Action Button & Quick Contact */}
          <div className="hidden lg:flex items-center gap-4">
            <a
              href="tel:09727421004"
              className="flex items-center gap-1.5 text-xs text-stone-300 hover:text-amber-400 transition-colors"
            >
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <span>097274 21004</span>
            </a>
            <button
              onClick={onOpenReservation}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-stone-950 font-semibold px-4 py-2 rounded-full text-sm shadow-md hover:shadow-amber-500/20 transition-all hover:-translate-y-0.5 active:translate-y-0"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Table</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={onOpenReservation}
              className="bg-amber-500 text-stone-950 text-xs font-semibold px-3 py-1.5 rounded-full"
            >
              Book Table
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-md text-stone-300 hover:text-white hover:bg-bungalow-800 focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <MenuIcon className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-bungalow-950/98 border-b border-bungalow-800 px-4 pt-3 pb-6 space-y-2 shadow-2xl">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2.5 rounded-lg text-base font-medium text-stone-200 hover:bg-amber-500/20 hover:text-amber-300 transition-colors"
            >
              {link.name}
            </a>
          ))}
          <div className="pt-4 border-t border-bungalow-800/80 flex flex-col gap-3">
            <a
              href="tel:09727421004"
              className="flex items-center gap-2 text-stone-300 text-sm px-3"
            >
              <Phone className="w-4 h-4 text-amber-400" />
              <span>Call: 097274 21004</span>
            </a>
            <div className="flex items-center gap-2 text-stone-400 text-xs px-3">
              <MapPin className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <span>B 401 Rivoli Heights, Vesu Main Road, Surat</span>
            </div>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenReservation();
              }}
              className="w-full mt-2 py-3 bg-gradient-to-r from-amber-500 to-amber-600 text-stone-950 font-bold rounded-xl flex items-center justify-center gap-2"
            >
              <span>Reserve a Table</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
