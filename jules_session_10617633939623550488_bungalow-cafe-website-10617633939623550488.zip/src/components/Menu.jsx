import React, { useState } from 'react';
import { Pizza, Flame, Coffee, Utensils, GlassWater, Search, Sparkles, Plus, ShoppingBag, Check } from 'lucide-react';

export const MENU_CATEGORIES = [
  { id: 'all', name: 'All Menu' },
  { id: 'pizzas', name: 'Pizzas' },
  { id: 'sizzlers', name: 'Sizzlers' },
  { id: 'coffees', name: 'Coffees & Drinks' },
  { id: 'continental', name: 'Continental' },
  { id: 'fastfood', name: 'Fast Food' },
  { id: 'lebanese', name: 'Lebanese & British' },
];

export const MENU_ITEMS = [
  // Pizzas
  {
    id: 'p1',
    category: 'pizzas',
    name: 'Bungalow Gourmet Special Pizza',
    description: 'Loaded with bell peppers, olives, jalapeños, sweet corn, and double mozzarella cheese.',
    price: '₹420',
    popular: true,
    tag: 'Scrumptious Pizza',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=600',
  },
  {
    id: 'p2',
    category: 'pizzas',
    name: 'Classico Margherita Supreme',
    description: 'Fresh basil leaves, tangy tomato pomodoro sauce, and melted buffalo cheese.',
    price: '₹340',
    popular: false,
    tag: 'Classic Italian',
    image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&q=80&w=600',
  },
  {
    id: 'p3',
    category: 'pizzas',
    name: 'Smoky Paneer Tikka Pizza',
    description: 'Chargrilled cottage cheese cubes, capsicum, red onion, drizzled with mint mayo sauce.',
    price: '₹390',
    popular: true,
    tag: 'Chef Choice',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&q=80&w=600',
  },
  {
    id: 'p4',
    category: 'pizzas',
    name: 'Fiery Jalapeño & Peri Peri Pizza',
    description: 'For spicy pizza lovers: spicy peri peri sauce, jalapeños, crushed chili, and cheese.',
    price: '₹380',
    popular: false,
    tag: 'Spicy',
    image: 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?auto=format&fit=crop&q=80&w=600',
  },

  // Sizzlers
  {
    id: 's1',
    category: 'sizzlers',
    name: 'The Bungalow Master Sizzler',
    description: 'Surat’s highest-rated sizzler platter with grilled vegetables, garlic herb rice, french fries, and rich pepper gravy.',
    price: '₹550',
    popular: true,
    tag: 'Surat #1 Sizzler',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=600',
  },
  {
    id: 's2',
    category: 'sizzlers',
    name: 'Exotic Cottage Cheese Sizzler',
    description: 'Pan-seared paneer steaks served on a sizzling hot plate with sautéed greens, potato wedges & barbecue sauce.',
    price: '₹520',
    popular: true,
    tag: 'Must Try',
    image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&q=80&w=600',
  },
  {
    id: 's3',
    category: 'sizzlers',
    name: 'Mexican Fiesta Sizzler',
    description: 'Sizzling Mexican rice, cheese nachos, stuffed peppers, and tangy salsa sauce served piping hot.',
    price: '₹510',
    popular: false,
    tag: 'Chef Special',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=600',
  },

  // Coffees & Drinks
  {
    id: 'c1',
    category: 'coffees',
    name: 'Handcrafted Bungalow Cappuccino',
    description: 'Rich espresso shot layered with steamed velvet milk foam and sprinkled with dark cocoa powder.',
    price: '₹180',
    popular: true,
    tag: 'Barista Special',
    image: 'https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&q=80&w=600',
  },
  {
    id: 'c2',
    category: 'coffees',
    name: 'Signature Hazelnut Iced Coffee',
    description: 'Chilled espresso blended with milk, sweet hazelnut, and topped with whipped cream.',
    price: '₹220',
    popular: true,
    tag: 'Customer Favorite',
    image: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&q=80&w=600',
  },
  {
    id: 'c3',
    category: 'coffees',
    name: 'Classic Dark Mocha Frappe',
    description: 'Rich espresso blended with Belgian chocolate and crushed ice, topped with chocolate drizzle.',
    price: '₹240',
    popular: false,
    tag: 'Refreshing',
    image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&q=80&w=600',
  },

  // Continental
  {
    id: 'cn1',
    category: 'continental',
    name: 'Creamy Alfredo Penne Pasta',
    description: 'Penne tossed in silky parmesan cream sauce with mushrooms, broccoli, and toasted garlic bread.',
    price: '₹360',
    popular: true,
    tag: 'Continental',
    image: 'https://images.unsplash.com/photo-1621996346565-e3def646d959?auto=format&fit=crop&q=80&w=600',
  },
  {
    id: 'cn2',
    category: 'continental',
    name: 'Baked Cheesy Vegetable Lasagna',
    description: 'Layers of flat pasta stuffed with garden vegetables, marinara sauce, and baked golden cheese.',
    price: '₹390',
    popular: false,
    tag: 'Baked Delight',
    image: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&q=80&w=600',
  },

  // Fast Food
  {
    id: 'ff1',
    category: 'fastfood',
    name: 'Crispy Bungalow Tower Burger',
    description: 'Double crunchy patty layered with cheddar cheese, lettuce, tomatoes, and house burger sauce.',
    price: '₹280',
    popular: true,
    tag: 'Fast Food',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=600',
  },
  {
    id: 'ff2',
    category: 'fastfood',
    name: 'Peri Peri Loaded Fries',
    description: 'Golden French fries tossed in fiery peri peri spice, smothered with molten cheese sauce.',
    price: '₹210',
    popular: false,
    tag: 'Snack Favorite',
    image: 'https://images.unsplash.com/photo-1576107232684-1279f390859f?auto=format&fit=crop&q=80&w=600',
  },

  // Lebanese & British
  {
    id: 'lb1',
    category: 'lebanese',
    name: 'Lebanese Falafel Wrap & Hummus',
    description: 'Crispy falafel balls wrapped in warm pita with creamy tahini, pickled veggies, and fresh hummus.',
    price: '₹310',
    popular: true,
    tag: 'Lebanese',
    image: 'https://images.unsplash.com/photo-1561651823-34feb02250e4?auto=format&fit=crop&q=80&w=600',
  },
  {
    id: 'lb2',
    category: 'lebanese',
    name: 'British Style Garlic Toasties',
    description: 'Toasted sourdough bread slathered with herb garlic butter and melted cheddar.',
    price: '₹240',
    popular: false,
    tag: 'British Classic',
    image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&q=80&w=600',
  },
];

export function Menu() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState([]);
  const [addedNotice, setAddedNotice] = useState(null);

  const filteredItems = MENU_ITEMS.filter((item) => {
    const matchesCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tag.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleAddToCart = (item) => {
    setCart((prev) => [...prev, item]);
    setAddedNotice(item.name);
    setTimeout(() => {
      setAddedNotice(null);
    }, 2500);
  };

  return (
    <section id="menu" className="py-20 bg-stone-900 text-stone-100 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Section */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-amber-400 font-bold uppercase text-xs tracking-widest bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
            Culinary Offerings
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-stone-100 mt-3 mb-4">
            Our Cafe & Restaurant Menu
          </h2>
          <p className="text-stone-400 text-sm sm:text-base">
            Explore our curated selection of scrumptious pizzas, sizzling platters, handcrafted coffees, Continental dishes, Fast Food, Lebanese & British delicacies.
          </p>
        </div>

        {/* Search Bar & Cart Notice */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-8">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
            <input
              type="text"
              placeholder="Search pizza, sizzler, coffee..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-stone-800/90 border border-stone-700 focus:border-amber-500 rounded-full pl-10 pr-4 py-2.5 text-xs sm:text-sm text-stone-100 placeholder-stone-400 focus:outline-none transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-white text-xs"
              >
                Clear
              </button>
            )}
          </div>

          {/* Cart Badge */}
          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <div className="flex items-center gap-2 bg-stone-800 border border-stone-700 px-4 py-2 rounded-full text-xs font-medium text-amber-300">
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              <span>Table Order Inquiry: <strong className="text-white font-bold">{cart.length} items</strong></span>
            </div>
          </div>
        </div>

        {/* Added to order notification popup */}
        {addedNotice && (
          <div className="mb-6 p-3 rounded-xl bg-amber-500 text-stone-950 font-medium text-xs sm:text-sm flex items-center justify-between shadow-lg animate-bounce">
            <span className="flex items-center gap-2">
              <Check className="w-4 h-4 font-bold" />
              Added <strong>"{addedNotice}"</strong> to your order selection!
            </span>
            <span className="text-stone-900 text-xs">Total selected: {cart.length}</span>
          </div>
        )}

        {/* Category Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {MENU_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2.5 rounded-full text-xs sm:text-sm font-semibold transition-all whitespace-nowrap shrink-0 ${
                activeCategory === cat.id
                  ? 'bg-amber-500 text-stone-950 shadow-md shadow-amber-500/20'
                  : 'bg-stone-800 text-stone-300 hover:bg-stone-700 hover:text-stone-100'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Menu Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-stone-800/40 rounded-2xl border border-stone-800">
            <p className="text-stone-400 text-base">No menu items found matching "{searchQuery}".</p>
            <button
              onClick={() => {
                setActiveCategory('all');
                setSearchQuery('');
              }}
              className="mt-4 px-4 py-2 bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 text-xs font-semibold rounded-full border border-amber-500/30"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                className="bg-stone-800/80 rounded-2xl overflow-hidden border border-stone-700/60 hover:border-amber-500/40 transition-all duration-300 flex flex-col group hover:-translate-y-1 shadow-lg"
              >
                {/* Image Frame */}
                <div className="relative h-48 overflow-hidden bg-stone-950">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 opacity-90"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-900 via-transparent to-transparent"></div>
                  
                  {item.popular && (
                    <span className="absolute top-3 left-3 bg-amber-500 text-stone-950 font-bold text-[10px] uppercase tracking-wider px-2.5 py-1 rounded-md shadow flex items-center gap-1">
                      <Sparkles className="w-3 h-3" />
                      Popular
                    </span>
                  )}

                  <span className="absolute bottom-3 right-3 bg-stone-950/80 backdrop-blur-md text-amber-300 font-bold text-sm px-3 py-1 rounded-full border border-amber-500/30">
                    {item.price}
                  </span>
                </div>

                {/* Card Content */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider">
                        {item.tag}
                      </span>
                    </div>

                    <h3 className="font-serif font-bold text-lg text-stone-100 group-hover:text-amber-300 transition-colors mb-2">
                      {item.name}
                    </h3>

                    <p className="text-stone-400 text-xs sm:text-sm leading-relaxed mb-4">
                      {item.description}
                    </p>
                  </div>

                  <button
                    onClick={() => handleAddToCart(item)}
                    className="w-full py-2.5 px-4 rounded-xl bg-stone-700/60 hover:bg-amber-500 hover:text-stone-950 text-stone-200 font-semibold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 group/btn"
                  >
                    <Plus className="w-4 h-4 group-hover/btn:rotate-90 transition-transform" />
                    <span>Add to Table Order Inquiry</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

export function Specials() {
  return (
    <section id="specials" className="py-20 bg-gradient-to-b from-bungalow-950 via-stone-900 to-bungalow-950 text-stone-100 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-amber-400 font-bold uppercase text-xs tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-full border border-amber-500/20">
            Surat Foodie Recommendations
          </span>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-stone-100 mt-3 mb-4">
            Signature House Specials
          </h2>
          <p className="text-stone-400 text-sm sm:text-base">
            What makes foodies return again and again to The Bungalow Cafe in Vesu.
          </p>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Sizzler Highlight */}
          <div className="relative rounded-3xl overflow-hidden bg-stone-800/80 border border-stone-700/80 p-6 sm:p-8 flex flex-col justify-between group hover:border-amber-500/50 transition-all shadow-xl">
            <div className="flex items-start justify-between mb-6">
              <div>
                <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/20 px-3 py-1 rounded-full border border-amber-500/30 inline-block mb-3">
                  1000% Surat Favorite Sizzler
                </span>
                <h3 className="text-2xl sm:text-3xl font-serif font-bold text-stone-100">
                  Unrivalled Sizzlers in Vesu
                </h3>
              </div>
              <div className="p-3 bg-amber-500/20 rounded-2xl text-amber-400">
                <Flame className="w-8 h-8" />
              </div>
            </div>

            <p className="text-stone-300 text-sm sm:text-base leading-relaxed mb-6">
              Reviewed by dining lovers as <em className="text-amber-200 font-serif">"One of the best sizzlers had in Surat 1000% leaving behind famous sizzler places."</em> Piping hot sizzler platters with grilled veggies, aromatic rice, golden fries, and rich homemade sauces.
            </p>

            <div className="rounded-2xl overflow-hidden h-52 mb-6">
              <img
                src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=800"
                alt="Signature Sizzler at Bungalow Cafe"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-stone-700">
              <span className="text-xs text-stone-400">Platter Specials from ₹510</span>
              <a
                href="#menu"
                className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
              >
                View Sizzler Menu &rarr;
              </a>
            </div>
          </div>

          {/* Pizza Highlight */}
          <div className="relative rounded-3xl overflow-hidden bg-stone-800/80 border border-stone-700/80 p-6 sm:p-8 flex flex-col justify-between group hover:border-amber-500/50 transition-all shadow-xl">
            <div className="flex items-start justify-between mb-6">
              <div>
                <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/20 px-3 py-1 rounded-full border border-amber-500/30 inline-block mb-3">
                  Scrumptious Pizza Delights
                </span>
                <h3 className="text-2xl sm:text-3xl font-serif font-bold text-stone-100">
                  Artisanal Hand-Tossed Pizzas
                </h3>
              </div>
              <div className="p-3 bg-amber-500/20 rounded-2xl text-amber-400">
                <Pizza className="w-8 h-8" />
              </div>
            </div>

            <p className="text-stone-300 text-sm sm:text-base leading-relaxed mb-6">
              Crafted for big-time foodies with fresh dough, aromatic herb-infused pizza sauce, generous layers of mozzarella cheese, and rich gourmet toppings baked to golden perfection.
            </p>

            <div className="rounded-2xl overflow-hidden h-52 mb-6">
              <img
                src="https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&q=80&w=800"
                alt="Scrumptious Pizza at Bungalow Cafe"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-stone-700">
              <span className="text-xs text-stone-400">Pizzas starting at ₹340</span>
              <a
                href="#menu"
                className="text-xs font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
              >
                View Pizza Selection &rarr;
              </a>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
