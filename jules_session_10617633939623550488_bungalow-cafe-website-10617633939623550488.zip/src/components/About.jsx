import React from 'react';
import { Pizza, Flame, HeartHandshake, Smile, Coffee, CheckCircle2 } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-bungalow-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          {/* Visual Grid / Image Frame */}
          <div className="relative">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white bg-bungalow-900">
              <img
                src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=1200"
                alt="Inside The Bungalow Cafe"
                className="w-full h-[420px] sm:h-[480px] object-cover hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-bungalow-950/80 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6 p-4 rounded-2xl bg-white/90 backdrop-blur-md shadow-lg border border-amber-100/50 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-amber-700">Vesu, Surat</p>
                  <p className="font-serif text-lg font-bold text-stone-900">Cozy Bungalow Vibe & Warm Hospitality</p>
                </div>
                <div className="p-3 bg-amber-500 rounded-xl text-stone-950 shadow">
                  <HeartHandshake className="w-6 h-6" />
                </div>
              </div>
            </div>

            {/* Floating Highlight Badge */}
            <div className="absolute -top-6 -right-4 sm:-right-6 bg-bungalow-950 text-amber-300 p-4 rounded-2xl shadow-xl border border-amber-500/30 flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400">
                <Flame className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs text-stone-400 font-medium">Famous Sizzler Spot</p>
                <p className="text-sm font-bold text-stone-100">Unmatched Sizzlers in Surat</p>
              </div>
            </div>
          </div>

          {/* Text Content */}
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-100 text-amber-800 text-xs font-semibold tracking-wide uppercase">
              <Coffee className="w-3.5 h-3.5 text-amber-600" />
              <span>Welcome to The Bungalow Cafe</span>
            </div>

            <h2 className="text-3xl sm:text-4xl md:text-5xl font-serif font-bold text-stone-900 leading-tight">
              A Warm Haven for Big-Time Foodies in Surat
            </h2>

            <p className="text-stone-600 text-base sm:text-lg leading-relaxed">
              They serve <strong className="text-amber-800 font-semibold">scrumptious pizzas</strong> for you to enjoy. The staff is kind and helpful. They serve the best kind of pizzas and is built for people who are big-time foodies.
            </p>

            <p className="text-stone-600 text-base leading-relaxed">
              Nestled at <span className="font-semibold text-stone-800">Rivoli Heights, Vesu Main Road</span>, The Bungalow Cafe brings together handcrafted artisan pizzas, bubbling mouthwatering sizzlers, Continental favorites, and specialty coffees in an inviting bungalow setting.
            </p>

            {/* Feature Checklist */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-3.5 rounded-2xl bg-white border border-stone-200 shadow-sm flex items-start gap-3">
                <Pizza className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-stone-900 text-sm">Scrumptious Pizzas</h4>
                  <p className="text-xs text-stone-500">Fresh dough & oven-baked perfection</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white border border-stone-200 shadow-sm flex items-start gap-3">
                <Flame className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-stone-900 text-sm">100% Top Sizzlers</h4>
                  <p className="text-xs text-stone-500">Sizzling hot, flavor-packed platters</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white border border-stone-200 shadow-sm flex items-start gap-3">
                <Smile className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-stone-900 text-sm">Kind & Helpful Staff</h4>
                  <p className="text-xs text-stone-500">Friendly hospitality every single visit</p>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white border border-stone-200 shadow-sm flex items-start gap-3">
                <Coffee className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-stone-900 text-sm">Rich Coffee & Beverages</h4>
                  <p className="text-xs text-stone-500">Espressos, frappes, teas & mocktails</p>
                </div>
              </div>
            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
